﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    class AXIS:IBANK
    {
        double IBANK.getRateOfInterest()

        {
            double rate = 9;
            return rate;
        }
    }
}
