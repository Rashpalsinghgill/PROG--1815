﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    public abstract class Driver
    {
        public abstract double area(double s);
        public abstract double vol(double s);


        public abstract double areaa(double r, double h);
        public abstract double voll(double r, double h);


        public abstract double rd(double r);
        public abstract double cir(double r);
    }
}
