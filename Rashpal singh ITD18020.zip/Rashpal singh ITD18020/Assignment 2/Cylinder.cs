﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    public class Cylinder:Driver
    {
        public override double rd(double r)
        {
            throw new NotImplementedException();
        }

        public override double area(double s)
        {
            throw new NotImplementedException();
        }

        public override double areaa(double r, double h)
        {
            double ab = 2 * 3.14 * r * (r + h);
            return ab;

        }

        public override double cir(double r)
        {
            throw new NotImplementedException();
        }

        public override double vol(double s)
        {
            throw new NotImplementedException();
        }

        public override double voll(double r, double h)
        {
            double ab = 3.14 * r * r * h;
            return ab;

        }
    }
}
