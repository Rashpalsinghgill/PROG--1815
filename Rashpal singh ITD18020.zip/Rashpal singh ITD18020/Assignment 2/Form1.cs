﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string a = textBox1.Text;
            int b = int.Parse(textBox2.Text);
            double c = double.Parse(textBox3.Text);
            Employee ab = new Employee();
            if (a.Any(char.IsDigit))
            {
                label4.Text = ab.validator();
                label4.ForeColor = Color.Red;
            }
            else
            {
                double d = ab.calculatesalary(b, c);
                label4.Text = a + "'s per day salary is " + d.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double rad = double.Parse(textBox4.Text);
            Driver obj = new Circle();
            double xx = obj.rd(rad);
            label22.Text = xx.ToString();
            double yy = obj.cir(rad);
            label23.Text = yy.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double rad = double.Parse(textBox5.Text);
            double he = double.Parse(textBox6.Text);
            Driver obj = new Cylinder();
            double xx = obj.areaa(rad, he);
            label8.Text = xx.ToString();
            double yy = obj.voll(rad, he);
            label9.Text = yy.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            double rad = double.Parse(textBox7.Text);

            Driver obj = new Cube();
            double xx = obj.area(rad);
            label26.Text = xx.ToString();
            double yy = obj.vol(rad);
            label27.Text = yy.ToString();
        }

        private void label27_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == 2)
            {

                IBANK sp = new SBI();
                double sbi = sp.getRateOfInterest();
                label16.Text = sbi.ToString();
            }
            if (listBox1.SelectedIndex == 3)
            {
                IBANK ml = new ICICI();
                double icici = ml.getRateOfInterest();
                label16.Text = icici.ToString();
            }
            if (listBox1.SelectedIndex == 4)
            {
                IBANK kk = new AXIS();
                double axis = kk.getRateOfInterest();
                label16.Text = axis.ToString();
            }
        }
    }
}
