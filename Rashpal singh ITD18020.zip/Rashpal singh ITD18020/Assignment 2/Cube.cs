﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    public class Cube:Driver
    {
        public override double rd(double r)
        {
            throw new NotImplementedException();
        }

        public override double area(double s)
        {
            double ab = 6 * s * s;
            return ab;
        }

        public override double areaa(double r, double h)
        {
            throw new NotImplementedException();
        }

        public override double cir(double r)
        {
            throw new NotImplementedException();
        }

        public override double vol(double s)
        {
            double ab = s * s * s;
            return ab;
        }

        public override double voll(double r, double h)
        {
            throw new NotImplementedException();
        }
    }
}
