﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Assignment_2
{
    public class Employee
    {
        
        string name;
        int hours_worked;
        double salary;
        double aa;
        string ab;

        public Employee()
        {
            name = "no name";
            hours_worked = 0;
            salary = 0;
        }

        public double calculatesalary(int hours, double salary)
        {
            aa = hours * salary;
            return aa;
        }

        public string validator()
        {
            ab = "";
            return ab;
        }
    }
}

